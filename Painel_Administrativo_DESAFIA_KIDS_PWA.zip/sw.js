const CACHE_NAME = "desafiamais-admin-v1";
const APP_SHELL = [
  "./admin.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  const request = event.request;
  const url = new URL(request.url);

  // Nunca guardar chamadas ao Supabase nem scripts externos em cache.
  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request).then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put("./admin.html", copy));
        return response;
      }).catch(() => caches.match("./admin.html"))
    );
    return;
  }

  if (url.pathname.includes("/icons/") || url.pathname.endsWith("/manifest.json")) {
    event.respondWith(
      caches.match(request).then(cached => cached || fetch(request))
    );
  }
});
